function ethsign(toaddress,value,privatekey,gasLimit,nonce,gasprice,con,dec){
	
	var sign="param error";
	
	gasprice=gasprice<6000000000?6000000000:gasprice;
	value=(value*Math.pow(10, dec));
	if (con==""){
		var sign=getEthSign(privatekey,nonce,gasprice,gasLimit,toaddress,value)
		console.log("sign:"+sign);
	}else{
		var sign=getEthTokenSign(privatekey,nonce,gasprice,gasLimit,toaddress,value,con)
		console.log("sign:"+sign);
	}
	
	  
	return sign
};


function getEthTokenSign(privkey,nonce,gasPrice,gasLimit,toaddress,value,con){
	var data =""
	data+='a9059cbb000000000000000000000000'
	var str=toaddress.substr(2, toaddress.length);
	data+=str
	
	var value = parseInt(value,10)
	value = value.toString(16);
	//console.log('data...==============='+value.length,value)
	var amount = ""
	for(var i=0;i<64-value.length;i++){
		amount+='0'
	}
	amount+=value
	
	data+=amount
	//console.log('data...========='+data)
	
	return getEthSign(privkey,nonce,gasPrice,gasLimit,con,'0',data)
	
			
}		
function getEthSign(privkey,nonce,gasPrice,gasLimit,toaddress,value,data){
			privkey=privkey.substring(2,privkey.length);
			value = parseInt(value)
			value = value.toString(16);
			gasPrice = parseInt(gasPrice)
			gasPrice = gasPrice.toString(16);
			nonce = parseInt(nonce)
			nonce = nonce.toString(16);
			gasLimit = parseInt(gasLimit)
			gasLimit = gasLimit.toString(16);
			
			var privateKey = new ethereumjs.Buffer.Buffer(privkey,'hex');
			var rawTx = {
			  nonce: '0x'+nonce,
			  gasPrice: '0x'+gasPrice,
			  gasLimit: '0x'+gasLimit,
			  to: toaddress, 
			  value: '0x'+value, 
			  data: '0x'+data
			}
			var tx = new ethereumjs.Tx(rawTx);
			tx.sign(privateKey);
			var serializedTx = tx.serialize();
			//console.log('0x'+serializedTx.toString('hex'));
			return '0x'+serializedTx.toString('hex');
}


//获取比特币或者代币交易签名
function getBtcSign(privatekey,toaddress,changeaddress,utxo,number,contractid,free){
	utxo = JSON.parse(utxo);
	//获取旷工费
	var inputs=utxo.length;
	var bytes=(inputs*148)+78;
	var bitcore = require('bitcore-lib');
	const privateKey = new bitcore.PrivateKey(privatekey);
	var data="";
	var value = 546;
	if (contractid != 1){
		//转换成16进制，长度不足十六自动补0
		var amount = parseInt(number*Math.pow(10,8)).toString(16);
		for (var i=amount.length;i<16;i++){
			amount = '0'+amount;
		}
		//发送btc代币需要拼接data
		//usdt代币编号31转成16进制-1f
		var coinnumber =parseInt(contractid).toString(16);
		for (var i=coinnumber.length;i<16;i++){
			coinnumber = '0'+coinnumber;
		}
		//发送btc代币需要拼接data
		data = bitcore.util.buffer.hexToBuffer('6f6d6e69'+coinnumber+amount);
	}else{
		value = parseInt(number*Math.pow(10,8))
	} 
	var transaction = new bitcore.Transaction()
	  .from(utxo) 			    //输入
	  .to(toaddress, value)     //输出
	  .addData(data)  			//OP_RETURN ，发送代币,发送btc不需要此参数
	  //.fee(bytes*20)			//矿工费
	  .fee(Number(free))		//矿工费0.00002
	  .change(changeaddress)    //找零地址
	  .sign(privateKey);		//签名私钥
	  var sign=transaction.toString();
	  //获取签名对象
	  return sign;
}











